from app.db.base_class import Base  # noqa
