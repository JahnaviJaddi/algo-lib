# -*- coding: utf-8 -*-
"""
Created on Tue Mar  1 08:40:42 2022

@author: Jahnavi
"""

def multiply (a,b):
    return a*b

def square_root(a):
    return a**0.5

def divide(a,b):
    return a/b if a>b else b/a